/**
 * The package includes I/O management tools.
 */
package pl.poznan.put.cs.io.errors.storage;