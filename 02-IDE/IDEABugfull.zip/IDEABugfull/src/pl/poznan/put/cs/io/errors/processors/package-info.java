/**
 * The package includes processors for searching tree data structures.
 */
package pl.poznan.put.cs.io.errors.processors;