/**
 * The package includes main program.
 */
package pl.poznan.put.cs.io.errors;